class DB:
    def __init__(self):
        """
        Use a db of your choice
        """
        pass

    def set(self, ip, email):
        pass
