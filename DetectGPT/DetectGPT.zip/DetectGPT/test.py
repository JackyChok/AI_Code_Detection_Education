# Python program to read CSV file line by line
# import necessary packages
import csv
import sys

sys.stdout.reconfigure(encoding='utf-8')
  
# Open file 
with open(r'C:\Users\User\FIT4701\FYP\DetectGPT\data\good_answer (1).csv', newline='', encoding="utf-8") as file_obj:
      
    # Create reader object by passing the file 
    # object to reader method
    reader_obj = csv.reader(file_obj)
      
    # Iterate over each row in the csv 
    # file using reader object
    for row in reader_obj:
        print(row[2], '\n')