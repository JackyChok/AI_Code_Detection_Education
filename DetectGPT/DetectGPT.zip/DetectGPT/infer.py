"""
This code a slight modification of perplexity by hugging face
https://huggingface.co/docs/transformers/perplexity

Both this code and the orignal code are published under the MIT license.

by Burhan Ul tayyab and Nicholas Chua
"""

from model import GPT2PPLV2 as GPT2PPL

import csv
import sys


# Set system encoding to utf-8 
sys.stdout.reconfigure(encoding='utf-8')
  
# Open file 
with open(r'data\good_answer (1).csv', newline='', encoding="utf-8") as file_obj:
      
    # Create reader object by passing the file 
    # object to reader method
    reader_obj = csv.reader(file_obj)
      
    # Iterate over each row in the csv 
    # file using reader object
    for row in reader_obj:
        sentence = row[2]

        # Initialize the model
        model = GPT2PPL()

        # Run the model on the sentence, with 100 tokens using version 1.1
        model(sentence, 100, "v1.1")